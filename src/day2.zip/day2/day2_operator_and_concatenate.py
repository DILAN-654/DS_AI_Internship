name=input("Enter Name: ")

print("Hello, ",name,"!")
print("Hello, "+name+"!")
print(f"Hello, {name} !")

