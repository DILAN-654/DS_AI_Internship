age=21
print(type(age))

height=5.8
print(type(height))

name="Adityaa"
print(type(name))

is_student=True
print(type(is_student))
