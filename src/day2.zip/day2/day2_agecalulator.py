print("Age Calculator!!!")
name=input(("Your name Please:"))
age=int(input("your present age:"))

new_age=age+4
print(f"\n Hey {name},your age will be {new_age} years old in the year 2030")
