item_name = "Laptop"
quantity = 2
price = 499.99
in_stock = True

print("===== Product Profile =====")
print(f"Item Name   : {item_name}")
print(f"Quantity    : {quantity}")
print(f"Price       : ₹{price}")
print(f"In Stock    : {in_stock}")
