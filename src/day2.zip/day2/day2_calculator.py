n=input("Enter number:")
print("Number :",n)
