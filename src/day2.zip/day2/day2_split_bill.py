print("Split bills in Restuarants")

total_bill=float(input("Enter the Total Bill Amount :"))
people_count=int(input("Enter the number of people: "))
shared_amount=total_bill/people_count
print("Total Bill : ",total_bill)
print("each person pays: ",shared_amount)
print(type(total_bill))
print(type(people_count))
print(type(shared_amount))
